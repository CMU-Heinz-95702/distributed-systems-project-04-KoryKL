// Aubrey Kuang
// AndrewID: yongbeik

package com.metmuseum.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.metmuseum.service.AnalyticsService;
import com.metmuseum.service.MongoDBClient;
import org.bson.Document;

/**
 * AnalyticsServlet
 *
 * This class provides REST API endpoints for the dashboard analytics.
 * It contains a hierarchy of servlet classes that retrieve different types of analytics data:
 * - Top searched keywords
 * - Most popular artworks
 * - Most popular artists
 * - Recent search logs
 *
 * The class implements a base servlet with common functionality and specialized
 * child servlets for each analytics type, promoting code reuse and maintainability.
 * All endpoints return formatted JSON data for consumption by the dashboard frontend.
 */
public class AnalyticsServlet {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    // Base class for all analytics servlets
    private static abstract class BaseAnalyticsServlet extends HttpServlet {
        @Override
        protected void doGet(HttpServletRequest request, HttpServletResponse response)
                throws ServletException, IOException {
            // Set CORS headers
            response.setHeader("Access-Control-Allow-Origin", "*");
            response.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
            response.setHeader("Content-Type", "application/json");

            try {
                List<Document> data = getData();
                String jsonResponse = GSON.toJson(data);
                response.getWriter().write(jsonResponse);
            } catch (Exception e) {
                System.err.println("Error processing analytics request: " + e.getMessage());
                e.printStackTrace();
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                response.getWriter().write("{\"error\": \"Failed to retrieve analytics data\"}");
            }
        }

        @Override
        protected void doOptions(HttpServletRequest request, HttpServletResponse response)
                throws ServletException, IOException {
            // Handle CORS preflight request
            response.setHeader("Access-Control-Allow-Origin", "*");
            response.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
            response.setHeader("Access-Control-Allow-Headers", "Content-Type");
            response.setStatus(HttpServletResponse.SC_NO_CONTENT);
        }

        // Abstract method to be implemented by each analytics servlet
        protected abstract List<Document> getData() throws Exception;
    }

//    @WebServlet("/api/analytics/keywords")
    public static class KeywordsServlet extends BaseAnalyticsServlet {
        @Override
        protected List<Document> getData() throws Exception {
            return AnalyticsService.getTopSearchKeywords(5);
        }
    }

    public static class ArtworksServlet extends BaseAnalyticsServlet {
        @Override
        protected List<Document> getData() throws Exception {
            return AnalyticsService.getTopArtworks(5);
        }
    }

    public static class ArtistsServlet extends BaseAnalyticsServlet {
        @Override
        protected List<Document> getData() throws Exception {
            return AnalyticsService.getTopArtists(5);
        }
    }

    public static class LogsServlet extends HttpServlet {
        @Override
        protected void doGet(HttpServletRequest request, HttpServletResponse response)
                throws ServletException, IOException {
            // Set CORS headers
            response.setHeader("Access-Control-Allow-Origin", "*");
            response.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
            response.setHeader("Access-Control-Allow-Headers", "Content-Type");
            response.setContentType("application/json");

            try {
                List<Document> logs = MongoDBClient.getRecentLogs(20);
                List<Map<String, Object>> formattedLogs = new ArrayList<>();

                // Format each log document for proper JSON serialization
                for (Document log : logs) {
                    Map<String, Object> formattedLog = new HashMap<>();

                    // Handle the requestInfo section
                    Document requestInfo = (Document) log.get("requestInfo");
                    if (requestInfo != null) {
                        formattedLog.put("requestInfo", requestInfo);
                    } else {
                        formattedLog.put("requestInfo", new HashMap<String, Object>());
                    }

                    // Extract searchKeyword and make sure it's at the top level
                    if (log.containsKey("searchKeyword")) {
                        formattedLog.put("searchKeyword", log.getString("searchKeyword"));
                    } else if (requestInfo != null && requestInfo.containsKey("searchKeyword")) {
                        formattedLog.put("searchKeyword", requestInfo.getString("searchKeyword"));
                    } else {
                        formattedLog.put("searchKeyword", "");
                    }

                    // Handle resultInfo section
                    if (log.containsKey("resultInfo")) {
                        formattedLog.put("resultInfo", log.get("resultInfo"));
                    } else {
                        formattedLog.put("resultInfo", new HashMap<String, Object>());
                    }

                    // Handle performance section
                    if (log.containsKey("performance")) {
                        formattedLog.put("performance", log.get("performance"));
                    } else {
                        formattedLog.put("performance", new HashMap<String, Object>());
                    }

                    formattedLogs.add(formattedLog);
                }

                String jsonResponse = GSON.toJson(formattedLogs);
                response.getWriter().write(jsonResponse);
            } catch (Exception e) {
                System.err.println("Error processing logs request: " + e.getMessage());
                e.printStackTrace();
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                response.getWriter().write("{\"error\": \"Failed to retrieve logs\"}");
            }
        }

        @Override
        protected void doOptions(HttpServletRequest request, HttpServletResponse response)
                throws ServletException, IOException {
            // Handle CORS preflight request
            response.setHeader("Access-Control-Allow-Origin", "*");
            response.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
            response.setHeader("Access-Control-Allow-Headers", "Content-Type");
            response.setStatus(HttpServletResponse.SC_NO_CONTENT);
        }
    }
}