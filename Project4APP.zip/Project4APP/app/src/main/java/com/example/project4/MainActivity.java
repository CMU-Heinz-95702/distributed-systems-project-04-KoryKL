// Aubrey Kuang
// AndrewID: yongbeik

package com.example.project4;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NoConnectionError;
import com.android.volley.TimeoutError;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    private static final int REQUEST_TIMEOUT = 10000;
    // UI Components
    private EditText etSearch;
    private Button btnSearch;
    private ProgressBar progressBar;
    private RecyclerView rvArtworks;
    private TextView tvEmptyState;

    // Adapter and Data
    private ArtworkAdapter adapter;
    private RequestQueue requestQueue;
    private List<Artwork> artworks = new ArrayList<>();

    // API base URL - make sure this matches your server address
//    private static final String BASE_URL = "http://10.0.2.2:8080";
    private static final String BASE_URL = "https://ubiquitous-space-goggles-gw76qp975x43p95j-8080.app.github.dev/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        etSearch = findViewById(R.id.etSearch);
        btnSearch = findViewById(R.id.btnSearch);
        progressBar = findViewById(R.id.progressBar);
        rvArtworks = findViewById(R.id.rvArtworks);
        tvEmptyState = findViewById(R.id.tvEmptyState);

        // Setup RecyclerView
        adapter = new ArtworkAdapter(artworks, this::showArtworkDetail);
        rvArtworks.setLayoutManager(new LinearLayoutManager(this));
        rvArtworks.setAdapter(adapter);

        // Initialize Volley request queue
        requestQueue = Volley.newRequestQueue(this);

        // Set click listener for search button
        btnSearch.setOnClickListener(v -> performSearch());
    }

    private void performSearch() {
        // First check network connectivity
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null && activeNetwork.isConnectedOrConnecting();

        if (!isConnected) {
            Toast.makeText(this, "No network connection. Please check your internet connection and try again.", Toast.LENGTH_LONG).show();
            return;
        }

        String query = etSearch.getText().toString().trim();
        if (query.isEmpty()) {
            Toast.makeText(this, "Please enter a search term", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check for special characters that might cause issues with the API
        if (query.matches(".*[<>\\(\\)\\{\\}\\[\\]\\\\|\\^\\*\\$].*")) {
            Toast.makeText(this, "Search contains invalid characters. Please avoid using special characters.", Toast.LENGTH_SHORT).show();
            return;
        }

        showLoading(true);
        // Use java.net.URLEncoder to properly encode the query parameter
        try {
            query = java.net.URLEncoder.encode(query, "UTF-8");
        } catch (java.io.UnsupportedEncodingException e) {
            Log.e(TAG, "Error encoding URL", e);
        }

        String url = BASE_URL + "/api/search?q=" + query;
        Log.d(TAG, "Search URL: " + url);

        JsonArrayRequest request = new JsonArrayRequest(
                Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        handleSearchArrayResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Enhanced error handling
                        if (error instanceof TimeoutError) {
                            Toast.makeText(MainActivity.this, "Request timed out. The server is taking too long to respond.", Toast.LENGTH_LONG).show();
                            showLoading(false);
                        } else if (error instanceof NoConnectionError) {
                            Toast.makeText(MainActivity.this, "Cannot connect to server. Please check your internet connection.", Toast.LENGTH_LONG).show();
                            showLoading(false);
                        } else {
                            // Try as a single object if array fails
                            JsonObjectRequest objectRequest = new JsonObjectRequest(
                                    Request.Method.GET, url, null,
                                    new Response.Listener<JSONObject>() {
                                        @Override
                                        public void onResponse(JSONObject response) {
                                            handleSearchResponse(response);
                                        }
                                    },
                                    new Response.ErrorListener() {
                                        @Override
                                        public void onErrorResponse(VolleyError error) {
                                            handleSearchError(error);
                                        }
                                    }
                            );
                            // Apply the same timeout policy to this request
                            objectRequest.setRetryPolicy(new DefaultRetryPolicy(
                                    REQUEST_TIMEOUT,
                                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
                            ));
                            requestQueue.add(objectRequest);
                        }
                    }
                }
        );

        // Set timeout and retry policy
        request.setRetryPolicy(new DefaultRetryPolicy(
                REQUEST_TIMEOUT,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
        ));

        requestQueue.add(request);
    }

    // Enhance the handleSearchError method to provide more specific error messages
    private void handleSearchError(VolleyError error) {
        String errorMessage = "Search failed";

        if (error instanceof TimeoutError) {
            errorMessage = "Request timed out. The server is taking too long to respond.";
        } else if (error instanceof NoConnectionError) {
            errorMessage = "Cannot connect to server. Please check your internet connection.";
        } else if (error.networkResponse != null) {
            switch (error.networkResponse.statusCode) {
                case 400:
                    errorMessage = "Bad request. Please try a different search term.";
                    break;
                case 404:
                    errorMessage = "Server endpoint not found. Please check the API URL.";
                    break;
                case 500:
                    errorMessage = "Server error. Please try again later.";
                    break;
                default:
                    errorMessage = "Error: Status Code " + error.networkResponse.statusCode;
                    break;
            }
        } else if (error.getMessage() != null) {
            errorMessage = "Error: " + error.getMessage();
        }

        Toast.makeText(this, errorMessage, Toast.LENGTH_LONG).show();
        Log.e(TAG, "Volley Error: " + error.toString());

        artworks.clear();
        updateUI();
        showLoading(false);
    }

    private void handleSearchArrayResponse(JSONArray response) {
        // Clear any existing artwork data to prepare for new results
        artworks.clear();

        try {
            // Iterate through each JSONObject in the response array
            for (int i = 0; i < response.length(); i++) {
                JSONObject obj = response.getJSONObject(i);

                // Create a new Artwork object for each item in the array
                Artwork artwork = new Artwork();

                // Extract required fields from JSON and set them in the Artwork object
                artwork.setObjectID(obj.getInt("objectID"));  // Get artwork ID as integer
                artwork.setTitle(obj.getString("title"));     // Get artwork title
                artwork.setArtist(obj.getString("artist"));   // Get artist name
                artwork.setImageUrl(obj.getString("imageUrl")); // Get image URL

                // Handle optional fields - check if they exist before extracting
                if (obj.has("culture") && !obj.isNull("culture")) {
                    artwork.setCulture(obj.getString("culture"));
                }
                if (obj.has("date") && !obj.isNull("date")) {
                    artwork.setDate(obj.getString("date"));
                }

                // Add the populated Artwork object to the collection
                artworks.add(artwork);
            }
        } catch (JSONException e) {
            // Handle any JSON parsing errors
            Toast.makeText(this, "Error parsing array results: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }

        // Update the UI with the new artwork data
        updateUI();

        // Hide the loading indicator
        showLoading(false);
    }

    private void handleSearchResponse(JSONObject response) {
        artworks.clear();
        try {
            Artwork artwork = new Artwork();
            artwork.setObjectID(response.getInt("objectID"));
            artwork.setTitle(response.getString("title"));
            artwork.setArtist(response.getString("artist"));
            artwork.setImageUrl(response.getString("imageUrl"));

            // These fields may not be present in all responses
            if (response.has("culture") && !response.isNull("culture")) {
                artwork.setCulture(response.getString("culture"));
            }
            if (response.has("date") && !response.isNull("date")) {
                artwork.setDate(response.getString("date"));
            }

            artworks.add(artwork);
        } catch (JSONException e) {
            Toast.makeText(this, "Error parsing object results: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }

        updateUI();
        showLoading(false);
    }

    private void updateUI() {
        adapter.notifyDataSetChanged();
        tvEmptyState.setVisibility(artworks.isEmpty() ? View.VISIBLE : View.GONE);
        rvArtworks.setVisibility(artworks.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void showLoading(boolean isLoading) {
        progressBar.setVisibility(isLoading ? View.VISIBLE : View.GONE);
        btnSearch.setEnabled(!isLoading);
    }

    private void showArtworkDetail(Artwork artwork) {
        // Implement detail view navigation here
        Toast.makeText(this, "Selected: " + artwork.getTitle(), Toast.LENGTH_SHORT).show();
    }
}