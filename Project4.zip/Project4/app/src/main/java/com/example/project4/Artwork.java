// Aubrey Kuang
// AndrewID: yongbeik
package com.example.project4;
public class Artwork {
    private int objectID;
    private String title;
    private String culture;
    private String imageUrl;
    private String artist;
    private String date;

    // Default constructor required for JSON parsing
    public Artwork() {
    }

    public Artwork(int objectID, String title, String culture, String imageUrl, String artist, String date) {
        this.objectID = objectID;
        this.title = title;
        this.culture = culture;
        this.imageUrl = imageUrl;
        this.artist = artist;
        this.date = date;
    }

    // Getters and setters
    public int getObjectID() {
        return objectID;
    }

    public void setObjectID(int objectID) {
        this.objectID = objectID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCulture() {
        return culture;
    }

    public void setCulture(String culture) {
        this.culture = culture;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}