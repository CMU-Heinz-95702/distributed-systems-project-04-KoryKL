// Aubrey Kuang
// AndrewID: yongbeik
package com.example.project4;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.List;

public class ArtworkAdapter extends RecyclerView.Adapter<ArtworkAdapter.ViewHolder> {
    private List<Artwork> artworks;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(Artwork artwork);
    }

    public ArtworkAdapter(List<Artwork> artworks, OnItemClickListener listener) {
        this.artworks = artworks;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_artwork, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.bind(artworks.get(position));
    }

    @Override
    public int getItemCount() {
        return artworks.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView tvTitle;
        private final TextView tvArtist;
        private final ImageView ivThumbnail;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvArtist = itemView.findViewById(R.id.tvArtist);
            ivThumbnail = itemView.findViewById(R.id.ivThumbnail);
        }

        public void bind(Artwork artwork) {
            tvTitle.setText(artwork.getTitle());
            tvArtist.setText(artwork.getArtist().isEmpty() ? "Unknown Artist" : artwork.getArtist());

            if (artwork.getImageUrl() != null && !artwork.getImageUrl().isEmpty()) {
                Glide.with(itemView)
                        .load(artwork.getImageUrl())
                        .placeholder(R.drawable.ic_placeholder)
                        .into(ivThumbnail);
            }

            itemView.setOnClickListener(v -> listener.onItemClick(artwork));
        }
    }
}