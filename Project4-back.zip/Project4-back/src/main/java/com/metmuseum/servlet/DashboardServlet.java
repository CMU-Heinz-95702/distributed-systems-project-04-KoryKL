// Aubrey Kuang
// AndrewID: yongbeik

package com.metmuseum.servlet;

import com.metmuseum.service.AnalyticsService;
import com.metmuseum.service.MongoDBClient;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.bson.Document;

/**
 * Servlet that handles requests to the dashboard page
 * Retrieves initial data for the dashboard view
 */
public class DashboardServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            // Check MongoDB connection
            boolean isConnected = MongoDBClient.testConnection();

            if (isConnected) {
                // Pre-fetch data for initial rendering
                try {
                    // Get analytics data
                    List<Document> keywords = AnalyticsService.getTopSearchKeywords(5);
                    List<Document> artworks = AnalyticsService.getTopArtworks(5);
                    List<Document> artists = AnalyticsService.getTopArtists(5);
                    List<Document> logs = MongoDBClient.getRecentLogs(20);

                    // Set as request attributes
                    request.setAttribute("keywords", keywords);
                    request.setAttribute("artworks", artworks);
                    request.setAttribute("artists", artists);
                    request.setAttribute("logs", logs);
                } catch (Exception e) {
                    System.err.println("Error fetching dashboard data: " + e.getMessage());
                    e.printStackTrace();
                    // Set empty lists as fallback
                    request.setAttribute("keywords", new ArrayList<>());
                    request.setAttribute("artworks", new ArrayList<>());
                    request.setAttribute("artists", new ArrayList<>());
                    request.setAttribute("logs", new ArrayList<>());
                }
            } else {
                // MongoDB connection failed - set empty lists
                request.setAttribute("mongoConnected", false);
                request.setAttribute("keywords", new ArrayList<>());
                request.setAttribute("artworks", new ArrayList<>());
                request.setAttribute("artists", new ArrayList<>());
                request.setAttribute("logs", new ArrayList<>());
            }
        } catch (Exception e) {
            System.err.println("Error in DashboardServlet: " + e.getMessage());
            e.printStackTrace();
        }


        request.getRequestDispatcher("/WEB-INF/dashboard.jsp").forward(request, response);

    }
}