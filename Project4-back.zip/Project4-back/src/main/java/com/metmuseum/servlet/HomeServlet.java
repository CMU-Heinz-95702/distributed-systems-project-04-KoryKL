// Aubrey Kuang
// AndrewID: yongbeik

package com.metmuseum.servlet;

import jakarta.servlet.http.*;
import java.io.IOException;

public class HomeServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        resp.sendRedirect("index.jsp");
    }
}
