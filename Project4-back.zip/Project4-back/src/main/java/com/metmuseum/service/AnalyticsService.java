// Aubrey Kuang
// AndrewID: yongbeik

package com.metmuseum.service;

import com.mongodb.client.AggregateIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Accumulators;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Sorts;
import org.bson.Document;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AnalyticsService {

    public static List<Document> getTopSearchKeywords(int limit) {
        List<Document> results = new ArrayList<>();
        try {
            MongoCollection<Document> logsCollection = MongoDBClient.getCollection("search_logs");

            AggregateIterable<Document> aggregate = logsCollection.aggregate(Arrays.asList(
                    Aggregates.match(Filters.exists("searchKeyword")),
                    Aggregates.group("$searchKeyword", Accumulators.sum("count", 1)),
                    Aggregates.sort(Sorts.descending("count")),
                    Aggregates.limit(limit)
            ));

            aggregate.into(results);
        } catch (Exception e) {
            System.err.println("Error getting top search keywords: " + e.getMessage());
            e.printStackTrace();
        }
        return results;
    }

    public static List<Document> getTopArtworks(int limit) {
        List<Document> results = new ArrayList<>();
        try {
            MongoCollection<Document> logsCollection = MongoDBClient.getCollection("search_logs");

            AggregateIterable<Document> aggregate = logsCollection.aggregate(Arrays.asList(
                    Aggregates.match(Filters.exists("resultInfo.artworkTitle")),
                    Aggregates.group("$resultInfo.artworkTitle", Accumulators.sum("count", 1)),
                    Aggregates.match(Filters.ne("_id", "No results found")),
                    Aggregates.sort(Sorts.descending("count")),
                    Aggregates.limit(limit)
            ));

            aggregate.into(results);
        } catch (Exception e) {
            System.err.println("Error getting top artworks: " + e.getMessage());
            e.printStackTrace();
        }
        return results;
    }

    public static List<Document> getTopArtists(int limit) {
        List<Document> results = new ArrayList<>();
        try {
            MongoCollection<Document> logsCollection = MongoDBClient.getCollection("search_logs");

            AggregateIterable<Document> aggregate = logsCollection.aggregate(Arrays.asList(
                    Aggregates.match(Filters.exists("resultInfo.artist")),
                    Aggregates.group("$resultInfo.artist", Accumulators.sum("count", 1)),
                    Aggregates.match(Filters.ne("_id", "N/A")),
                    Aggregates.sort(Sorts.descending("count")),
                    Aggregates.limit(limit)
            ));

            aggregate.into(results);
        } catch (Exception e) {
            System.err.println("Error getting top artists: " + e.getMessage());
            e.printStackTrace();
        }
        return results;
    }
}