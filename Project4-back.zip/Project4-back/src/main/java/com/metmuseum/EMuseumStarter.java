// Aubrey Kuang
// AndrewID: yongbeik

package com.metmuseum;

import com.metmuseum.service.MongoDBClient;
import com.metmuseum.servlet.ArtworkSearchServlet;
import com.metmuseum.servlet.DashboardServlet;
import com.metmuseum.servlet.AnalyticsServlet;
import com.metmuseum.servlet.TestServlet;
import org.apache.catalina.Context;
import org.apache.catalina.connector.Connector;
import org.apache.catalina.startup.Tomcat;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * EMuseumStarter
 *
 * Main application entry point that bootstraps the web service.
 * This class:
 * - Configures and initializes an embedded Tomcat server
 * - Sets up the servlet context and necessary endpoints
 * - Performs critical dependency checks (MongoDB and Met Museum API)
 * - Displays available API endpoints for reference
 * - Handles graceful startup and error conditions
 *
 * The application provides art search functionality via RESTful API endpoints
 * and a web-based operations dashboard for analytics and monitoring.
 */
public class EMuseumStarter {
    public static void main(String[] args) throws Exception {
        try {
            // Create Tomcat instance
            Tomcat tomcat = new Tomcat();

            int port = 8080;
            tomcat.setPort(port);

            Connector connector = new Connector();
            connector.setPort(port);
            tomcat.getService().addConnector(connector);
            tomcat.setConnector(connector);

            // Configure temporary directory
            String tmpDir = System.getProperty("java.io.tmpdir");
            tomcat.setBaseDir(tmpDir);

            // Get current directory as docBase
            String webappDirLocation = "src/main/webapp/";
            File webappDir = new File(webappDirLocation);
            if (!webappDir.exists()) {
                webappDir = new File(".");
            }

            // Create context
            String contextPath = "";
            Context context = tomcat.addWebapp(contextPath, webappDir.getAbsolutePath());
            System.out.println("Configuring app with basedir: " + webappDir.getAbsolutePath());

            // Check MongoDB connection
            boolean mongoConnected = MongoDBClient.testConnection();
            if (mongoConnected) {
                System.out.println("MongoDB connection verified successfully.");
            } else {
                System.err.println("WARNING: Could not connect to MongoDB. Dashboard and logging will not work properly.");
            }

            // Check third-party API availability (Met Museum API)
            boolean metApiAvailable = isThirdPartyApiAvailable("https://collectionapi.metmuseum.org/public/collection/v1/objects/1");
            if (metApiAvailable) {
                System.out.println("Met Museum API is available.");
            } else {
                System.err.println("WARNING: Met Museum API is currently unavailable. Some features may not work correctly.");
            }

            // Start server
            tomcat.start();
            System.out.println("Server started: http://localhost:" + port);
            System.out.println("API endpoints:");
            System.out.println("  - /api/search?q=<query>  (Search artwork)");
            System.out.println("  - /dashboard  (View operations dashboard)");

            // Wait for requests
            tomcat.getServer().await();

        } catch (Exception e) {
            System.err.println("Error starting Tomcat:");
            e.printStackTrace();
        }
    }

    /**
     * Checks if a third-party API is available by sending a test request
     *
     * @param apiUrl The URL to test
     * @return true if the API is available, false otherwise
     */
    private static boolean isThirdPartyApiAvailable(String apiUrl) {
        try {
            URL url = new URL(apiUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);

            int responseCode = connection.getResponseCode();
            return (responseCode >= 200 && responseCode < 300);
        } catch (Exception e) {
            System.err.println("Error checking third-party API availability: " + e.getMessage());
            return false;
        }
    }
}