// Aubrey Kuang
// AndrewID: yongbeik

package com.metmuseum.service;

import com.mongodb.WriteConcern;
import com.mongodb.client.MongoCollection;
import org.bson.Document;

import jakarta.servlet.http.HttpServletRequest;
import java.util.Date;


public class LoggingService {

    /**
     * Log details about the search request, Met Museum API interaction, and response
     */
    public static void logSearchActivity(HttpServletRequest request, String searchQuery,
                                         long requestStartTime, long thirdPartyApiStartTime,
                                         long thirdPartyApiEndTime, ArtworkService.ArtworkResponse artwork,
                                         int statusCode) {

        // Create a separate thread for logging to prevent blocking the API
        Thread loggingThread = new Thread(() -> {
            try {
                // Get MongoDB collection
                MongoCollection<Document> logsCollection = MongoDBClient.getCollection("search_logs");

                // Calculate timing information
                long totalRequestTime = System.currentTimeMillis() - requestStartTime;
                long thirdPartyApiTime = thirdPartyApiEndTime - thirdPartyApiStartTime;

                // 1. Request metadata from the mobile phone
                Document requestInfo = new Document()
                        .append("timestamp", new Date(requestStartTime))
                        .append("clientIp", request.getRemoteAddr())
                        .append("userAgent", request.getHeader("User-Agent"))
                        .append("httpMethod", request.getMethod());

                // 2. User search keyword
                // 6. Search timestamp (already included in requestInfo)

                // 3-4-5. Result information (artwork title, artist, style)
                Document resultInfo = new Document();
                if (artwork != null) {
                    resultInfo.append("artworkTitle", artwork.title)  // 3. Artwork title
                            .append("artist", artwork.artist)        // 4. Artist information
                            .append("style", artwork.culture);       // 5. Artwork style
                } else {
                    resultInfo.append("artworkTitle", "No results found")
                            .append("artist", "N/A")
                            .append("style", "N/A");
                }

                // Performance metrics
                Document performance = new Document()
                        .append("totalRequestTimeMs", totalRequestTime)
                        .append("thirdPartyApiTimeMs", thirdPartyApiTime)
                        .append("statusCode", statusCode);

                // Create complete log document with all 6 required data points
                Document logEntry = new Document()
                        .append("requestInfo", requestInfo)               // Contains #1 and #6
                        .append("searchKeyword", searchQuery)             // #2
                        .append("resultInfo", resultInfo)                 // Contains #3, #4, and #5
                        .append("performance", performance);

                // Try to insert with unacknowledged write concern for better performance
                logsCollection.withWriteConcern(WriteConcern.UNACKNOWLEDGED).insertOne(logEntry);

                System.out.println("Search log recorded: " + searchQuery);
            } catch (Exception e) {
                System.err.println("Failed to log search: " + e.getMessage());
                e.printStackTrace();
                // Don't let this affect the main application
            }
        });

        // Start logging in background without waiting for it to complete
        loggingThread.setDaemon(true); // Don't let logging threads prevent app shutdown
        loggingThread.start();
    }
}