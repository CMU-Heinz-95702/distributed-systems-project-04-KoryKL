package com.metmuseum.service;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import org.bson.Document;
import java.util.ArrayList;
import java.util.List;

public class MongoDBClient {
    private static final String CONN_STRING = "mongodb://Aubrey:Aubrey66@ac-ncyinwt-shard-00-00.jcqvoi4.mongodb.net:27017,ac-ncyinwt-shard-00-01.jcqvoi4.mongodb.net:27017,ac-ncyinwt-shard-00-02.jcqvoi4.mongodb.net:27017/Cluster0?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1&authSource=admin";
    private static MongoClient instance;

    public static synchronized MongoClient getInstance() {
        if (instance == null) {
            try {
                instance = MongoClients.create(CONN_STRING);
                // Verify connection works immediately
                testConnection();
            } catch (Exception e) {
                System.err.println("Error initializing MongoDB client: " + e.getMessage());
                e.printStackTrace();
            }
        }
        return instance;
    }

    public static MongoCollection<Document> getCollection(String collectionName) {
        return getInstance().getDatabase("Cluster0").getCollection(collectionName);
    }

    public static boolean testConnection() {
        try {
            MongoClient client = getInstance();
            // Try to access the database and run a simple command
            client.getDatabase("Cluster0").runCommand(new Document("ping", 1));
            System.out.println("Successfully connected to MongoDB!");
            return true;
        } catch (Exception e) {
            System.err.println("Failed to connect to MongoDB: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public static List<Document> getRecentLogs(int limit) {
        List<Document> logs = new ArrayList<>();
        try {
            MongoCollection<Document> collection = getCollection("search_logs");
            // Print collection name and count for debugging
            System.out.println("Collection: " + collection.getNamespace());
            System.out.println("Document count: " + collection.countDocuments());

            collection.find()
                    .sort(new Document("requestInfo.timestamp", -1))
                    .limit(limit)
                    .into(logs);

            System.out.println("Retrieved " + logs.size() + " logs");
        } catch (Exception e) {
            System.err.println("Error fetching logs: " + e.getMessage());
            e.printStackTrace();
        }
        return logs;
    }
}