// Aubrey Kuang
// AndrewID: yongbeik

package com.metmuseum.service;

import com.mongodb.client.AggregateIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Accumulators;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Sorts;
import org.bson.Document;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * AnalyticsService
 *
 * This service provides analytics functionality for the dashboard by running
 * aggregation pipelines against the MongoDB search logs collection.
 *
 * The service includes methods to identify:
 * - Most frequently searched keywords
 * - Most popular artworks returned in search results
 * - Most popular artists featured in search results
 *
 * Each method uses MongoDB's aggregation framework for efficient data analysis.
 */

public class AnalyticsService {

    /**
     * Retrieves the most frequently searched keywords
     *
     * @param limit Maximum number of results to return
     * @return List of Documents containing keywords and their counts
     */
    public static List<Document> getTopSearchKeywords(int limit) {
        List<Document> results = new ArrayList<>();
        try {
            MongoCollection<Document> logsCollection = MongoDBClient.getCollection("search_logs");

            // Create MongoDB aggregation pipeline:
            // 1. Filter for documents with searchKeyword field
            // 2. Group by searchKeyword and count occurrences
            // 3. Sort by count (highest first)
            // 4. Limit to requested number of results
            AggregateIterable<Document> aggregate = logsCollection.aggregate(Arrays.asList(
                    Aggregates.match(Filters.exists("searchKeyword")),
                    Aggregates.group("$searchKeyword", Accumulators.sum("count", 1)),
                    Aggregates.sort(Sorts.descending("count")),
                    Aggregates.limit(limit)
            ));

            aggregate.into(results);
        } catch (Exception e) {
            System.err.println("Error getting top search keywords: " + e.getMessage());
            e.printStackTrace();
        }
        return results;
    }

    /**
     * Retrieves the most frequently returned artworks in search results
     *
     * @param limit Maximum number of results to return
     * @return List of Documents containing artwork titles and their counts
     */
    public static List<Document> getTopArtworks(int limit) {
        List<Document> results = new ArrayList<>();
        try {
            MongoCollection<Document> logsCollection = MongoDBClient.getCollection("search_logs");

            AggregateIterable<Document> aggregate = logsCollection.aggregate(Arrays.asList(
                    Aggregates.match(Filters.exists("resultInfo.artworkTitle")),
                    Aggregates.group("$resultInfo.artworkTitle", Accumulators.sum("count", 1)),
                    Aggregates.match(Filters.ne("_id", "No results found")),
                    Aggregates.sort(Sorts.descending("count")),
                    Aggregates.limit(limit)
            ));

            aggregate.into(results);
        } catch (Exception e) {
            System.err.println("Error getting top artworks: " + e.getMessage());
            e.printStackTrace();
        }
        return results;
    }

    /**
     * Retrieves the most frequently returned artists in search results
     *
     * @param limit Maximum number of results to return
     * @return List of Documents containing artist names and their counts
     */
    public static List<Document> getTopArtists(int limit) {
        List<Document> results = new ArrayList<>();
        try {
            MongoCollection<Document> logsCollection = MongoDBClient.getCollection("search_logs");

            // Create MongoDB aggregation pipeline:
            // 1. Filter for documents with artist field
            // 2. Group by artist name and count occurrences
            // 3. Filter out "N/A" entries (where no artist was found)
            // 4. Sort by count (highest first)
            // 5. Limit to requested number of results
            AggregateIterable<Document> aggregate = logsCollection.aggregate(Arrays.asList(
                    Aggregates.match(Filters.exists("resultInfo.artist")),
                    Aggregates.group("$resultInfo.artist", Accumulators.sum("count", 1)),
                    Aggregates.match(Filters.ne("_id", "N/A")),
                    Aggregates.sort(Sorts.descending("count")),
                    Aggregates.limit(limit)
            ));

            aggregate.into(results);
        } catch (Exception e) {
            System.err.println("Error getting top artists: " + e.getMessage());
            e.printStackTrace();
        }
        return results;
    }
}