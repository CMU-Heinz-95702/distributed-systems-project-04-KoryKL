// Aubrey Kuang
// AndrewID: yongbeik

package com.metmuseum.servlet;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.metmuseum.service.ArtworkService;
import com.metmuseum.service.LoggingService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class ArtworkSearchServlet extends HttpServlet {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final String SEARCH_API = "https://collectionapi.metmuseum.org/public/collection/v1/search";
    private static final String OBJECT_API = "https://collectionapi.metmuseum.org/public/collection/v1/objects/";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Record the start time of the request
        long requestStartTime = System.currentTimeMillis();
        long thirdPartyApiStartTime = 0;
        long thirdPartyApiEndTime = 0;
        int statusCode = 200;

        // Set response type
        response.setContentType("application/json");

        // Parse query parameter
        String searchQuery = request.getParameter("q");
        if (searchQuery == null || searchQuery.isEmpty()) {
            String errorResponse = "{\"error\":\"Missing query parameter\"}";
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write(errorResponse);
            statusCode = HttpServletResponse.SC_BAD_REQUEST;

            // Log the failed request
            LoggingService.logSearchActivity(
                    request, "invalid_query", requestStartTime,
                    requestStartTime, requestStartTime, null, statusCode);
            return;
        }

        try {
            // Record third-party API request start time
            thirdPartyApiStartTime = System.currentTimeMillis();

            // Get the first valid artwork ID
            Integer objectId = fetchFirstValidObjectId(searchQuery);

            ArtworkService.ArtworkResponse artwork = null;

            if (objectId == null) {
                String emptyResponse = "[]";
                response.getWriter().write(emptyResponse);

                // Record third-party API end time
                thirdPartyApiEndTime = System.currentTimeMillis();

                // Log the search with no results
                LoggingService.logSearchActivity(
                        request, searchQuery, requestStartTime,
                        thirdPartyApiStartTime, thirdPartyApiEndTime, null, HttpServletResponse.SC_OK);
                return;
            }

            // Get single artwork details
            artwork = fetchSingleArtwork(objectId);

            // Record third-party API end time
            thirdPartyApiEndTime = System.currentTimeMillis();

            // Return results
            String jsonResponse = GSON.toJson(artwork);
            response.getWriter().write(jsonResponse);

            // Log the successful search
            LoggingService.logSearchActivity(
                    request, searchQuery, requestStartTime,
                    thirdPartyApiStartTime, thirdPartyApiEndTime, artwork, HttpServletResponse.SC_OK);

        } catch (Exception e) {
            e.printStackTrace();
            statusCode = HttpServletResponse.SC_INTERNAL_SERVER_ERROR;
            String errorResponse = "{\"error\":\"Server error: " + e.getMessage() + "\"}";
            response.setStatus(statusCode);
            response.getWriter().write(errorResponse);

            // Record third-party API end time (if not already set)
            if (thirdPartyApiEndTime == 0) {
                thirdPartyApiEndTime = System.currentTimeMillis();
            }

            // Log the failed search
            LoggingService.logSearchActivity(
                    request, searchQuery, requestStartTime,
                    thirdPartyApiStartTime, thirdPartyApiEndTime, null, statusCode);
        }
    }

    // Get the first valid artwork ID
    private Integer fetchFirstValidObjectId(String query) throws IOException {
        String encodedQuery = URLEncoder.encode(query, StandardCharsets.UTF_8);
        URL url = new URL(SEARCH_API + "?q=" + encodedQuery + "&hasImages=true");

        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setConnectTimeout(10000); // 10 seconds connection timeout
        conn.setReadTimeout(10000);    // 10 seconds read timeout
        try {
            if (conn.getResponseCode() != 200) {
                System.err.println("Met Museum API search unavailable, status code: " + conn.getResponseCode());
                return null;
            }

            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder responseStr = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                responseStr.append(line);
            }
            reader.close();

            JsonObject jsonObj = JsonParser.parseString(responseStr.toString()).getAsJsonObject();
            if (!jsonObj.has("objectIDs") || jsonObj.get("objectIDs").isJsonNull()) {
                return null;
            }

            JsonArray objectIds = jsonObj.getAsJsonArray("objectIDs");

            // Find the first valid ID
            for (JsonElement id : objectIds) {
                int objectId = id.getAsInt();
                if (isValidArtwork(objectId)) {
                    return objectId;
                }
            }
            return null;

        } catch (SocketTimeoutException e) {
            System.err.println("Connection to Met Museum API timed out: " + e.getMessage());
            return null;
        } catch (IOException e) {
            System.err.println("Unable to connect to Met Museum API: " + e.getMessage());
            return null;
        }
    }

    // Check if artwork is valid
    private boolean isValidArtwork(int objectId) {
        try {
            ArtworkService.ArtworkResponse artwork = fetchSingleArtwork(objectId);
            return artwork != null &&
                    artwork.imageUrl != null &&
                    !artwork.imageUrl.isEmpty();
        } catch (Exception e) {
            return false;
        }
    }

    // Get single artwork details
    private ArtworkService.ArtworkResponse fetchSingleArtwork(int objectId) throws IOException {
        URL url = new URL(OBJECT_API + objectId);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(10000);

        if (conn.getResponseCode() != 200) return null;

        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder response = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            response.append(line);
        }
        reader.close();

        return ArtworkService.parseArtwork(response.toString());
    }
}