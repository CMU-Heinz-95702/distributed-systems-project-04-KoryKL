// Aubrey Kuang
// AndrewID: yongbeik

package com.metmuseum.service;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mongodb.client.MongoCollection;
import org.bson.Document;

public class ArtworkService {
    public static class ArtworkResponse {
        public int objectID;
        public String title;
        public String culture;
        public String imageUrl;
        public String artist;
        public String date;
    }

    public static ArtworkResponse parseArtwork(String json) {
        try {
            JsonObject obj = JsonParser.parseString(json).getAsJsonObject();
            ArtworkResponse response = new ArtworkResponse();

            // Ensure necessary fields exist
            if (!obj.has("objectID")) {
                System.err.println("API response missing objectID field");
                return null;
            }

            response.objectID = getIntValue(obj, "objectID");
            response.title = getStringValue(obj, "title");

            // Validate if image URL is valid
            String imageUrl = getStringValue(obj, "primaryImageSmall");
            if (imageUrl == null || imageUrl.isEmpty()) {
                // Try alternative image
                imageUrl = getStringValue(obj, "primaryImage");
                if (imageUrl == null || imageUrl.isEmpty()) {
                    // Use placeholder image
                    imageUrl = "https://placehold.co/300x200?text=Sample&font=roboto";
                }
            }
            response.imageUrl = imageUrl;

            response.culture = getStringValue(obj, "culture");
            response.artist = getStringValue(obj, "artistDisplayName");
            response.date = getStringValue(obj, "objectDate");

            return response;
        } catch (Exception e) {
            System.err.println("Error parsing Met Museum API response: " + e.getMessage());
            return null;
        }
    }

    private static String getStringValue(JsonObject obj, String key) {
        return obj.has(key) && !obj.get(key).isJsonNull() ? obj.get(key).getAsString() : "";
    }

    private static int getIntValue(JsonObject obj, String key) {
        return obj.has(key) && !obj.get(key).isJsonNull() ? obj.get(key).getAsInt() : -1;
    }

    /**
     * Saves an artwork to MongoDB collection
     * @param artwork The artwork to be saved
     * @return Whether the save operation was successful
     */
    public static boolean saveToCollection(ArtworkResponse artwork) {
        try {
            // Get the artworks collection from MongoDB
            MongoCollection<Document> collection = MongoDBClient.getCollection("artworks");

            // Check if an artwork with the same objectID already exists
            Document existing = collection.find(new Document("objectID", artwork.objectID)).first();

            // If it already exists, don't perform any operation (or optionally update the existing record)
            if (existing != null) {
                return true; // Consider it successful if it already exists
            }

            // Create a new document
            Document doc = new Document()
                    .append("objectID", artwork.objectID)
                    .append("title", artwork.title)
                    .append("culture", artwork.culture)
                    .append("imageUrl", artwork.imageUrl)
                    .append("artist", artwork.artist)
                    .append("date", artwork.date);

            // Insert the document
            collection.insertOne(doc);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Retrieves the list of collected artworks from MongoDB
     * @return JSON string of the artwork list
     */
    public static String getCollectionAsJson() {
        // A method to retrieve the collection list can be added here if needed
        return "[]"; // Temporarily returns an empty list
    }
}